package com.axreng.backend.data;

public class RequestData {
    public String keyword;
}
