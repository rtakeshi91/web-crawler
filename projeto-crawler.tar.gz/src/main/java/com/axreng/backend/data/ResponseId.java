package com.axreng.backend.data;

public class ResponseId {
    String id;

    public ResponseId(String id) {
        this.id = id;
    }
}
